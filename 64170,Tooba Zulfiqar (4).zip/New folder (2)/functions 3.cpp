#include<iostream>
using namespace std;
 //functio definition
 int passByrefrence(int num)	
  {
 	num = num+10;//modifying the value
 	cout<<"inside function (pass by refrence)"<<num<<endl;
	 return num; }	
 int main()	
   {int number=5;
    cout<<"before function call:"<<number<<endl;
    passByrefrence(number);//passing the value
    cout<<"after function call:"<<number<<endl;

	
	return 0;
}