#include<iostream>
using namespace std;
 //function definition
 void sub(int a,int b)	
  {
 	int sub=a-b;
 	cout<<"subtraction of two numbers"<<sub<<endl; }	
void mul(int x, int y)
  {double mul=x*y;
  cout<<"multiplication of two numbers are:"<<mul<<endl;}
  
 int main()	
   {int a=5;
   int b=5;
    cout<<"before (sub) function call:"<<endl<<"a is"<<a<<endl<<"b is"<<b<<endl;
    sub(a,b);
	mul(a,b);

	
	return 0;
}